//Responsive Hamburger Menu
let clickBar = document.querySelector(".fa-bars")
let clickCross = document.querySelector(".fa-xmark")
let menu = document.querySelector(".Navbar-Menu")

clickBar.addEventListener("click", () => {
  clickBar.classList.toggle("hide")
  clickCross.classList.toggle("hide")
  menu.classList.toggle("hidden")
})

clickCross.addEventListener("click", () => {
  clickBar.classList.toggle("hide")
  clickCross.classList.toggle("hide")
  menu.classList.toggle("hidden")
})

//Logo Image Change On Click
function changeLogo() {
  let displayImage = document.getElementById("logo")
  if (displayImage.src.match("./Images/logo.png")) {
    displayImage.src = "./Images/Harry.png"
  } else {
    displayImage.src = "./Images/logo.png"
  }
}

//Background Image Change On Click
function changeImage() {
  document.getElementById("welcomeCastle").style.backgroundImage =
    "url(./Images/2.webp)"
}

//Flying Harry Stop And Fly
function stopFlying() {
  let animationPlayState = document.getElementById("flying")
  if (flying.style.animationPlayState.match("running")) {
    flying.style.animationPlayState = "paused"
  } else {
    flying.style.animationPlayState = "running"
  }
}
